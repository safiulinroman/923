#!/bin/bash
INI_FILE="/etc/php/8.2/apache2/php.ini"
if [ "$EUID" -ne 0 ]; then
  echo "Ошибка: Этот скрипт нужно запускать с правами sudo!"
  exit 1
fi
if [ ! -f "$INI_FILE" ]; then
  echo "Ошибка: Файл $INI_FILE не найден!"
  exit 1
fi
update_param() {
  local param=$1
  local value=$2
  if grep -qE "^;?\s*${param}\s*=" "$INI_FILE"; then

    sed -i -E "s/^;?\s*(${param}\s*=).*/\1 ${value}/" "$INI_FILE"
  else
    echo "${param} = ${value}" >> "$INI_FILE"
  fi
}
echo "Обновление параметров в $INI_FILE..."
update_param "display_errors" "On"
update_param "display_startup_errors" "On"
update_param "error_reporting" "E_ALL \& ~E_NOTICE"
if systemctl is-active --quiet apache2; then
  systemctl restart apache2
  echo "Настройки успешно применены. Apache перезапущен."
else
  echo "Настройки изменены, но Apache не запущен или имя службы отличается. Перезапустите его вручную."
fi
